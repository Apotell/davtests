// Leaf module, served from a subdirectory entry (rtl/leaf.sv) inside the tar
// archive to exercise TarFileStore's nested-path handling.
module leaf(input logic a, output logic b);
  assign b = ~a;
endmodule
