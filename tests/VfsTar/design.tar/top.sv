// Top module for the VFS Tar integration test. Compiled from inside a .tar
// archive mounted via the `-tar` CLI option (TarFileStore backend) rather than
// from the local filesystem (LocalStore).
module top;
  logic x, y;
  leaf u_leaf(.a(x), .b(y));
endmodule
